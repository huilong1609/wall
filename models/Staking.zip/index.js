const { sequelize } = require('../config/database');

// Import model definitions
const UserModel = require('./User');
const WalletModel = require('./Wallet');
const TransactionModel = require('./Transaction');
const OrderModel = require('./Order');
const TradeModel = require('./Trade');
const AssetModel = require('./Asset');
const TradingPairModel = require('./TradingPair');
const NotificationModel = require('./Notification');
const TicketModel = require('./Ticket');
const { TicketMessageModel } = require('./Ticket');
const StakingModels = require('./Staking');
const ReferralModels = require('./Referral');
const PriceAlertModel = require('./PriceAlert');
const CopyTradingModels = require('./CopyTrading');
const { SessionModel, ApiKeyModel } = require('./Session');

// Initialize models
const User = UserModel(sequelize);
const Wallet = WalletModel(sequelize);
const Transaction = TransactionModel(sequelize);
const Order = OrderModel(sequelize);
const Trade = TradeModel(sequelize);
const Asset = AssetModel(sequelize);
const TradingPair = TradingPairModel(sequelize);
const Notification = NotificationModel(sequelize);
const Ticket = TicketModel(sequelize);
const TicketMessage = TicketMessageModel(sequelize);
const { StakingPool, StakingPosition } = StakingModels(sequelize);
const { Referral, ReferralEarning } = ReferralModels(sequelize);
const PriceAlert = PriceAlertModel(sequelize);
const { TraderProfile, CopyRelation } = CopyTradingModels(sequelize);
const Session = SessionModel(sequelize);
const ApiKey = ApiKeyModel(sequelize);

// Define Associations

// User associations
User.hasMany(Wallet, { foreignKey: 'userId', as: 'wallets' });
User.hasMany(Transaction, { foreignKey: 'userId', as: 'transactions' });
User.hasMany(Order, { foreignKey: 'userId', as: 'orders' });
User.hasMany(Trade, { foreignKey: 'userId', as: 'trades' });
User.hasMany(Notification, { foreignKey: 'userId', as: 'notifications' });
User.hasMany(Ticket, { foreignKey: 'userId', as: 'tickets' });
User.hasMany(StakingPosition, { foreignKey: 'userId', as: 'stakingPositions' });
User.hasMany(PriceAlert, { foreignKey: 'userId', as: 'priceAlerts' });
User.hasMany(Session, { foreignKey: 'userId', as: 'sessions' });
User.hasMany(ApiKey, { foreignKey: 'userId', as: 'apiKeys' });
User.hasOne(TraderProfile, { foreignKey: 'userId', as: 'traderProfile' });

// Self-referential for referrals
User.belongsTo(User, { foreignKey: 'referredById', as: 'referrer' });
User.hasMany(User, { foreignKey: 'referredById', as: 'referrals' });

// Wallet associations
Wallet.belongsTo(User, { foreignKey: 'userId', as: 'user' });
Wallet.hasMany(Transaction, { foreignKey: 'walletId', as: 'transactions' });

// Transaction associations
Transaction.belongsTo(User, { foreignKey: 'userId', as: 'user' });
Transaction.belongsTo(Wallet, { foreignKey: 'walletId', as: 'wallet' });
Transaction.belongsTo(Order, { foreignKey: 'orderId', as: 'order' });

// Order associations
Order.belongsTo(User, { foreignKey: 'userId', as: 'user' });
Order.hasMany(Trade, { foreignKey: 'orderId', as: 'trades' });
Order.hasMany(Transaction, { foreignKey: 'orderId', as: 'transactions' });

// Trade associations
Trade.belongsTo(User, { foreignKey: 'userId', as: 'user' });
Trade.belongsTo(Order, { foreignKey: 'orderId', as: 'order' });

// Notification associations
Notification.belongsTo(User, { foreignKey: 'userId', as: 'user' });

// Ticket associations
Ticket.belongsTo(User, { foreignKey: 'userId', as: 'user' });
Ticket.hasMany(TicketMessage, { foreignKey: 'ticketId', as: 'messages' });
TicketMessage.belongsTo(Ticket, { foreignKey: 'ticketId', as: 'ticket' });

// Staking associations
StakingPool.hasMany(StakingPosition, { foreignKey: 'poolId', as: 'positions' });
StakingPosition.belongsTo(User, { foreignKey: 'userId', as: 'user' });
StakingPosition.belongsTo(StakingPool, { foreignKey: 'poolId', as: 'pool' });

// Referral associations
Referral.belongsTo(User, { foreignKey: 'referrerId', as: 'referrer' });
Referral.belongsTo(User, { foreignKey: 'referredId', as: 'referred' });
Referral.hasMany(ReferralEarning, { foreignKey: 'referralId', as: 'earnings' });
ReferralEarning.belongsTo(Referral, { foreignKey: 'referralId', as: 'referral' });

// Price Alert associations
PriceAlert.belongsTo(User, { foreignKey: 'userId', as: 'user' });

// Copy Trading associations
TraderProfile.belongsTo(User, { foreignKey: 'userId', as: 'user' });
TraderProfile.hasMany(CopyRelation, { foreignKey: 'traderProfileId', as: 'copiers' });
CopyRelation.belongsTo(User, { foreignKey: 'copierId', as: 'copier' });
CopyRelation.belongsTo(User, { foreignKey: 'traderId', as: 'trader' });
CopyRelation.belongsTo(TraderProfile, { foreignKey: 'traderProfileId', as: 'traderProfile' });

// Session associations
Session.belongsTo(User, { foreignKey: 'userId', as: 'user' });

// API Key associations
ApiKey.belongsTo(User, { foreignKey: 'userId', as: 'user' });

// Export models
module.exports = {
  sequelize,
  User,
  Wallet,
  Transaction,
  Order,
  Trade,
  Asset,
  TradingPair,
  Notification,
  Ticket,
  TicketMessage,
  StakingPool,
  StakingPosition,
  Referral,
  ReferralEarning,
  PriceAlert,
  TraderProfile,
  CopyRelation,
  Session,
  ApiKey,
};
