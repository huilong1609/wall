const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Wallet = sequelize.define('Wallet', {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    userId: {
      type: DataTypes.UUID,
      allowNull: false,
      field: 'user_id',
      references: {
        model: 'users',
        key: 'id',
      },
    },
    type: {
      type: DataTypes.ENUM('spot', 'futures', 'margin', 'funding', 'earn'),
      defaultValue: 'spot',
    },
    currency: {
      type: DataTypes.STRING(20),
      allowNull: false,
    },
    available: {
      type: DataTypes.DECIMAL(30, 18),
      defaultValue: 0,
    },
    locked: {
      type: DataTypes.DECIMAL(30, 18),
      defaultValue: 0,
    },
    pending: {
      type: DataTypes.DECIMAL(30, 18),
      defaultValue: 0,
    },
    staked: {
      type: DataTypes.DECIMAL(30, 18),
      defaultValue: 0,
    },
    depositAddress: {
      type: DataTypes.STRING(255),
      field: 'deposit_address',
    },
    depositMemo: {
      type: DataTypes.STRING(100),
      field: 'deposit_memo',
    },
    status: {
      type: DataTypes.ENUM('active', 'frozen', 'suspended'),
      defaultValue: 'active',
    },
    lockReason: {
      type: DataTypes.TEXT,
      field: 'lock_reason',
    },
    lockedAt: {
      type: DataTypes.DATE,
      field: 'locked_at',
    },
    lockedBy: {
      type: DataTypes.UUID,
      field: 'locked_by',
    },
  }, {
    tableName: 'wallets',
    timestamps: true,
    underscored: true,
    indexes: [
      { unique: true, fields: ['user_id', 'type', 'currency'] },
      { fields: ['user_id'] },
      { fields: ['currency'] },
      { fields: ['status'] },
    ],
  });

  // Instance Methods
  Wallet.prototype.getTotal = function () {
    return parseFloat(this.available) + parseFloat(this.locked) + parseFloat(this.staked);
  };

  Wallet.prototype.addBalance = async function (amount, type = 'available') {
    this[type] = parseFloat(this[type]) + parseFloat(amount);
    return this.save();
  };

  Wallet.prototype.subtractBalance = async function (amount, type = 'available') {
    if (parseFloat(this[type]) < parseFloat(amount)) {
      throw new Error('Insufficient balance');
    }
    this[type] = parseFloat(this[type]) - parseFloat(amount);
    return this.save();
  };

  Wallet.prototype.lockBalance = async function (amount) {
    if (parseFloat(this.available) < parseFloat(amount)) {
      throw new Error('Insufficient available balance');
    }
    this.available = parseFloat(this.available) - parseFloat(amount);
    this.locked = parseFloat(this.locked) + parseFloat(amount);
    return this.save();
  };

  Wallet.prototype.unlockBalance = async function (amount) {
    if (parseFloat(this.locked) < parseFloat(amount)) {
      throw new Error('Insufficient locked balance');
    }
    this.locked = parseFloat(this.locked) - parseFloat(amount);
    this.available = parseFloat(this.available) + parseFloat(amount);
    return this.save();
  };

  // Class Methods
  Wallet.getOrCreate = async function (userId, type = 'spot', currency = 'USDT') {
    const [wallet] = await this.findOrCreate({
      where: { userId, type, currency },
      defaults: { userId, type, currency },
    });
    return wallet;
  };

  return Wallet;
};
